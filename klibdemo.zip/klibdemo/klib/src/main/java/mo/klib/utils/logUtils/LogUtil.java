package mo.klib.utils.logUtils;


/**
 * @ author：mo
 * @ data：2017/11/29：14:29
 * @ 功能：log工具类
 */
public class LogUtil {


    private LogUtil() {
    }


    public static void v(String str) {
        LogUtilHelp.log(LogUtilHelp.V, str, LogUtilHelp.generateTag());

    }

    public static void d(String str) {
        LogUtilHelp.log(LogUtilHelp.D, str, LogUtilHelp.generateTag());

    }

    public static void i(String str) {
        LogUtilHelp.log(LogUtilHelp.I, str, LogUtilHelp.generateTag());

    }

    public static void i(Object object) {
        LogUtilHelp.log(LogUtilHelp.I, String.valueOf(object), LogUtilHelp.generateTag());

    }

    public static void e(String str) {
        LogUtilHelp.log(LogUtilHelp.E, str, LogUtilHelp.generateTag());

    }

    public static void w(String str) {
        LogUtilHelp.log(LogUtilHelp.W, str, LogUtilHelp.generateTag());

    }

    public static void a(String str) {
        LogUtilHelp.log(LogUtilHelp.A, str, LogUtilHelp.generateTag());

    }


}
