package mo.klib.modle.datum.design.strategy;

/**
 * @ author：mo
 * @ data：2019/1/16
 * @ 功能：
 */
public class z {
//    使用场景：分离算法和使用 ，当一个运算的参数类型，个数相同，运算方法不同，并且可能经常切换算法时，可以考虑
//
//    class：
//    IStrategy：接口类，声明要干什么
//    DTA：实现类，实现IStrategy接口，具体要怎么干，也就是要怎么算
//    ETC：实现类，实现IStrategy接口，具体要怎么干，也就是要怎么算
//    BitStrategy：策略类，通过带参构造或者set方法，把具体的实现类传入，通过get方法 拿到运算得出的值
}
