package mo.klib.modle.listener.keybordListener;

/**
 * @ author：mo
 * @ data：2017/11/22 0022
 * @ 功能：
 */
public interface KOnKeybordChangeListener {
    /**
    *  显示
    */
    void onKeyboardShow();

    /**
    *  隐藏
    */
    void onKeyboardHidden();
}
