package mo.klib.modle.listener.scrollingListener;

/**
 * @ author：mo
 * @ data：2017/11/24：14:32
 * @ 功能：自定义滑动监听
 */
public interface KOnScrollingListener {
    void onScrollingListener(int showPosition, int count);
}
