package mo.klib.modle.listener.clickListener;

import android.content.DialogInterface;


/**
 * @ author：mo
 * @ data：2017/11/17 0017
 * @ 功能：Dialog点击接口实现方法
 */
public class KOnDialogClickListenerImpl implements KOnDialogClickListener {
    @Override
    public void onSure(DialogInterface dialog, int which) {

    }

    @Override
    public void onCancel(DialogInterface dialog, int which) {

    }
}
