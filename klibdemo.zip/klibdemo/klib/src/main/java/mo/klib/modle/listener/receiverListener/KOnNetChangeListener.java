package mo.klib.modle.listener.receiverListener;

/**
 * @ author：mo
 * @ data：2018/10/25
 * @ 功能：网络变化监听
 */
public interface KOnNetChangeListener {
    void onNetChange(int netType);
}
