package mo.klib.modle.datum.design.factory.factorySimple;


/**
 * @author：mo
 * @data：2018/5/31 0031
 * @功能：
 */

public class lisi implements KView {
    @Override
    public void answer(String aaa) {
        System.err.print("李四"+aaa);
    }
}
