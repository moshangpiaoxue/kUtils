package mo.klib.modle.datum.design.proxy.proxyDynamic;

/**
 * @ author：mo
 * @ data：2019/1/16
 * @ 功能：
 */
public class z {
//    动态代理，严格意义上来说指的并不是一种代理模式，而是一种反射的运用技术，它可以在程序运行时通过反射创建一个目标接口的代理对象，
//    是实现代理模式的一种途径。
}
