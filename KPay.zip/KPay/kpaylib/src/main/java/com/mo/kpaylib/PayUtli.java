//package com.mo.kpaylib;
//
//import android.app.Activity;
//
//import com.alipay.sdk.app.PayTask;
//import com.mo.kpaylib.payModle1.Base64;
//import com.mo.kpaylib.payModle1.PayResult;
//
//import java.io.UnsupportedEncodingException;
//import java.util.Map;
//
///**
// * @ author：mo
// * @ data：2019/4/15:16:01
// * @ 功能：
// */
//public class PayUtli {
//    public interface PayCallBack1 {
//        void parResult(PayResult payResult);
//    }
//
//    public interface PayCallBack2 {
//        void parResult(com.mo.kpaylib.payModle2.PayResult payResult);
//    }
//
//    /**
//     * 异步调用方法
//     */
//    private static void actionPay(Runnable runnable) {
//        // 必须异步调用
//        Thread payThread = new Thread(runnable);
//        payThread.start();
//    }
//
//    /**
//     * 支付方式1，基于16年的jar包，后台生成的订单数据
//     */
//    public static void payModle1(final Activity mActivity, String orderStr, final PayCallBack1 callBack) {
//        final byte[] decode = Base64.decode(orderStr);
//        Runnable runnable = new Runnable() {
//            @Override
//            public void run() {
//
//                try {
//                    //支付宝需要的加密后的信息
//                    String payInfo = new String(decode, "UTF-8");
//                    //构造PayTask 对象
//                    PayTask alipay = new PayTask(mActivity);
//                    // 调用支付接口，获取支付结果
//                    String result = alipay.pay(payInfo, true);
//                    PayResult payResult = new PayResult(result);
//                    callBack.parResult(payResult);
//                } catch (UnsupportedEncodingException e1) {
//                    e1.printStackTrace();
//                }
//            }
//        };
//        actionPay(runnable);
//    }
//
//    /**
//     * 支付方式2，基于19年的aar包，后台生成的订单数据
//     */
//    public static void payModle2(final Activity mActivity, final String orderStr, final PayCallBack2 callBack) {
//        Runnable runnable = new Runnable() {
//            @Override
//            public void run() {
//
//                PayTask alipay = new PayTask(mActivity);
//                Map<String, String> result = alipay.payV2(orderStr, true);
//                com.mo.kpaylib.payModle2.PayResult payResult = new com.mo.kpaylib.payModle2.PayResult(result);
//                callBack.parResult(payResult);
//            }
//        };
//        actionPay(runnable);
//    }
//}
