package com.mo.kpay;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        PayUtli.payModle1(this, resault, new PayUtli.PayCallBack1() {
//            @Override
//            public void parResult(com.mo.kpaylib.payModle1.PayResult payResult) {
//                toast(payResult.getMemo());
//            }
//        });
//        PayUtli.payModle2(this, resault, new PayUtli.PayCallBack2() {
//            @Override
//            public void parResult(PayResult payResult) {
//                toast(payResult.getMemo());
//            }
//        });
    }

    private void toast(String toast) {
        Log.i("AAAAA==", toast);
    }

    private String resault = "YXBwX2lkPTIwMTYwNTE4MDE0MTMzMDEmYml6X2NvbnRlbnQ9JTdCJTIyb3V0X3RyYWRlX25vJTIyJTNBJTIyMjAxOTA0MTUxNTE4NTU4MDQlMjIlMkMlMjJwYXNzYmFja19wYXJhbXMlMjIlM0ElMjIlMjU3QiUyNTIydG93YXR0VXNlcklEJTI1MjIlMjUzQSUyNTIyMTI4OSUyNTIyJTI1MkMlMjUyMmFjdGl2aXR5SWQlMjUyMiUyNTNBJTI1MjIwJTI1MjIlMjU3RCUyMiUyQyUyMnByb2R1Y3RfY29kZSUyMiUzQSUyMlFVSUNLX01TRUNVUklUWV9QQVklMjIlMkMlMjJzdWJqZWN0JTIyJTNBJTIyJUU3JTg5JUI5JUU3JTkzJUE2JUU3JTg5JUI5JUU4JUI0JUE2JUU2JTg4JUI3JUU1JTg1JTg1JUU1JTgwJUJDLSVFNiU5NCVBRiVFNCVCQiU5OCVFNSVBRSU5REFQUCUyMiUyQyUyMnRvdGFsX2Ftb3VudCUyMiUzQSUyMjEwMCUyMiU3RCZjaGFyc2V0PXV0Zi04JmZvcm1hdD1KU09OJm1ldGhvZD1hbGlwYXkudHJhZGUuYXBwLnBheSZub3RpZnlfdXJsPWh0dHBzJTNBJTJGJTJGaW50ZXN0LnRvd2F0dC5jbiUzQTMwMDAxJTJGd3glMkZwYXklMkZjYWxsYmFjayUyRmFsaSUyRmFwcENhbGxiYWNrLmRvJnNpZ25fdHlwZT1SU0EmdGltZXN0YW1wPTIwMTktMDQtMTUlMjAxNSUzQTE4JTNBNTUmdmVyc2lvbj0xLjAmc2lnbj1iRXBNUjU5MjRldXVJN0ZDJTJCJTJCREROYzJJbXMwWkdMSmM5N21URzZEeFFUSGpJUFJIT1h4bU1RMFB6T010aUV1YlR0UVBhTFk3YW5jQ2xDdHE1QXkxZiUyRkJPc256Qzd4MWtLd3dPRlJLQkFxNG42VTRnOXhMVWxKRGFEQ21xZUNJaFZjVHpRd3BlTndEeCUyRjQzVWIwN0NTMVlxMVA2amdaZFQ0RVZyQyUyQm1YJTJCRHMlM0Q=";


}
