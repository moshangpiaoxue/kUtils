package com.mo.kbugly;

import android.app.Application;

import com.mo.kbuglylib.BuglyUtil;
import com.tencent.tinker.loader.app.TinkerApplication;
import com.tencent.tinker.loader.shareutil.ShareConstants;


/**
 * @ author：mo
 * @ data：2019/5/30:10:28
 * @ 功能：
 */
public class App extends TinkerApplication {

    public App() {
        super(ShareConstants.TINKER_ENABLE_ALL, "com.mo.kbugly.AALike",
                "com.tencent.tinker.loader.TinkerLoader", false);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        BuglyUtil.InitBugly(getApplicationContext(), "993b585d6a", true);
    }


}
