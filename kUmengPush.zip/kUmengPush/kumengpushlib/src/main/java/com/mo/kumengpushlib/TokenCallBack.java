package com.mo.kumengpushlib;

/**
 * @ author：mo
 * @ data：2019/5/24:15:34
 * @ 功能：
 */
public interface TokenCallBack {
    void getToken(String deviceToken);
}
