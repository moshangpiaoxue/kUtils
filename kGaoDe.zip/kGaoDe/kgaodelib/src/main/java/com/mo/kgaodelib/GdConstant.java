package com.mo.kgaodelib;

/*
 * 作者：M
 * 日期：2019/5/7
 * 作用：高德常量类
 * */

public class GdConstant {
    //经度
    public static double longitude = 0;
    //纬度
    public static double latitude = 0;
    //城市
    public static String CITY;
}
