//package com.mo.kpay.ali;
//
//import android.app.Activity;
//import android.util.Log;
//
//import com.alipay.sdk.app.PayTask;
//import com.mo.kpay.ali.aliModle.modle16.Base64;
//import com.mo.kpay.ali.aliModle.modle16.PayResult;
//
//import java.io.UnsupportedEncodingException;
//import java.util.Map;
//
///**
// * @ author：mo
// * @ data：2019/4/15:16:01
// * @ 功能：阿里支付
// */
//public class AliPayUtli {
//    public interface PayCallBack {
//        void parResult(PayResult payResult);
//    }
//
//
//    /**
//     * 支付方式16，基于16年的jar包，后台生成的订单数据
//     */
//    public static void payModle16(final Activity mActivity, String orderStr, final PayCallBack callBack) {
//        final byte[] decode = Base64.decode(orderStr);
////        new Thread(new Runnable() {
////            @Override
////            public void run() {
////                try {
////                    //支付宝需要的加密后的信息
////                    String payInfo = new String(decode, "UTF-8");
////                    //构造PayTask 对象
////                    PayTask alipay = new PayTask(mActivity);
////                    // 调用支付接口，获取支付结果
////                    String result = alipay.pay(payInfo, true);
////                    Log.i("支付结果==",result);
//////                    PayResult payResult = new PayResult(result);
//////                    callBack.parResult(payResult);
////                } catch (UnsupportedEncodingException e1) {
////                    e1.printStackTrace();
////                }
////            }
////        }).start();
//
//        Runnable payRunnable = new Runnable() {
//            @Override
//            public void run() {
//                try {
//                    //支付宝需要的加密后的信息
//                    String payInfo = new String(decode, "UTF-8");
//                    //构造PayTask 对象
//                    PayTask alipay = new PayTask(mActivity);
//                    // 调用支付接口，获取支付结果
//                    String result = alipay.pay(payInfo, true);
//                    Log.i("支付结果==", result);
//                    PayResult payResult = new PayResult(result);
//                    callBack.parResult(payResult);
//                } catch (UnsupportedEncodingException e1) {
//                    e1.printStackTrace();
//                }
//            }
//        };
//        Thread payThread = new Thread(payRunnable);
//        payThread.start();
//    }
//
//    /**
//     * 支付方式18，基于18年的jar包，后台生成的订单数据
//     */
//    public static void payModle18(final Activity mActivity, final String orderStr, final PayCallBack callBack) {
//        final byte[] decode = Base64.decode(orderStr);
//        Runnable payRunnable = new Runnable() {
//            @Override
//            public void run() {
//                try {
//                    //支付宝需要的加密后的信息
//                    String payInfo = new String(decode, "UTF-8");
//                    //构造PayTask 对象
//                    PayTask alipay = new PayTask(mActivity);
//                    // 调用支付接口，获取支付结果
//                    String result = alipay.pay(payInfo, true);
//                    Log.i("支付结果==", result);
//                    Map<String, String> result1 = alipay.payV2(orderStr, true);
//                    PayResult payResult = new PayResult(result1);
//                    callBack.parResult(payResult);
//                } catch (UnsupportedEncodingException e1) {
//                    e1.printStackTrace();
//                }
//            }
//        };
//        Thread payThread = new Thread(payRunnable);
//        payThread.start();
////        new Thread(new Runnable() {
////            @Override
////            public void run() {
////
////                PayTask alipay = new PayTask(mActivity);
////                String payInfo = new String(decode, "UTF-8");
////                Map<String, String> result = alipay.payV2(orderStr, true);
////                com.mo.kpay.ali.aliModle.modle2.PayResult payResult = new com.mo.kpay.ali.aliModle.modle2.PayResult(result);
////                callBack.parResult(payResult);
////            }
////        }).start();
//    }
//}
