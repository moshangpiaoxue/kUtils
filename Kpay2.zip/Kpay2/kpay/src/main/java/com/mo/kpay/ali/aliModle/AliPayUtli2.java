//package com.mo.kpay.ali.aliModle;
//
//import android.app.Activity;
//import android.util.Log;
//
//import com.alipay.sdk.app.PayTask;
//import com.mo.kpay.ali.aliModle.modle16.Base64;
//import com.mo.kpay.ali.aliModle.modle16.PayResult;
//
//import java.io.UnsupportedEncodingException;
//import java.util.Map;
//
///**
// * @ author：mo
// * @ data：2019/4/24:15:16
// * @ 功能：
// */
//public class AliPayUtli2 {
//    public interface PayCallBack {
//        void parResult(PayResult payResult);
//    }
//
//    /**
//     */
//    public static void payModle(final Activity mActivity, String orderStr, final PayCallBack callBack) {
//        final byte[] decode = Base64.decode(orderStr);
//
//        Runnable payRunnable = new Runnable() {
//            @Override
//            public void run() {
//                try {
//                    //支付宝需要的加密后的信息
//                    String payInfo = new String(decode, "UTF-8");
//                    //构造PayTask 对象
//                    PayTask alipay = new PayTask(mActivity);
//                    // 调用支付接口，获取支付结果
//                    String result = alipay.pay(payInfo, true);
//                    Log.i("支付结果==", result);
//                    Map<String, String> result1 = alipay.payV2(result, true);
//                    PayResult payResult = new PayResult(result1);
//                    callBack.parResult(payResult);
//                } catch (UnsupportedEncodingException e1) {
//                    e1.printStackTrace();
//                }
//            }
//        };
//        Thread payThread = new Thread(payRunnable);
//        payThread.start();
//    }
//}
