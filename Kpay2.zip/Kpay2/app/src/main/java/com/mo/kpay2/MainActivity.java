package com.mo.kpay2;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;



public class MainActivity extends AppCompatActivity {
    String oo = "YXBwX2lkPTIwMTYwNTE4MDE0MTMzMDEmYml6X2NvbnRlbnQ9JTdCJTIyb3V0X3RyYWRlX25vJTIyJTNBJTIyMjAxOTA0MjQwOTU3NDY0NjElMjIlMkMlMjJwYXNzYmFja19wYXJhbXMlMjIlM0ElMjIlMjU3QiUyNTIydG93YXR0VXNlcklEJTI1MjIlMjUzQSUyNTIyMTI5MCUyNTIyJTI1MkMlMjUyMmFjdGl2aXR5SWQlMjUyMiUyNTNBJTI1MjIwJTI1MjIlMjU3RCUyMiUyQyUyMnByb2R1Y3RfY29kZSUyMiUzQSUyMlFVSUNLX01TRUNVUklUWV9QQVklMjIlMkMlMjJzdWJqZWN0JTIyJTNBJTIyJUU3JTg5JUI5JUU3JTkzJUE2JUU3JTg5JUI5JUU4JUI0JUE2JUU2JTg4JUI3JUU1JTg1JTg1JUU1JTgwJUJDLSVFNiU5NCVBRiVFNCVCQiU5OCVFNSVBRSU5REFQUCUyMiUyQyUyMnRvdGFsX2Ftb3VudCUyMiUzQSUyMjUwJTIyJTdEJmNoYXJzZXQ9dXRmLTgmZm9ybWF0PUpTT04mbWV0aG9kPWFsaXBheS50cmFkZS5hcHAucGF5Jm5vdGlmeV91cmw9aHR0cHMlM0ElMkYlMkZpbnRlc3QudG93YXR0LmNuJTNBMzAwMDElMkZ3eCUyRnBheSUyRmNhbGxiYWNrJTJGYWxpJTJGYXBwQ2FsbGJhY2suZG8mc2lnbl90eXBlPVJTQSZ0aW1lc3RhbXA9MjAxOS0wNC0yNCUyMDA5JTNBNTclM0E0NiZ2ZXJzaW9uPTEuMCZzaWduPWVHSERQbXpHbkFFOHFKSUJkdWhtdUROOUtDb3p0NmxpRmRCYjZvVW1lUlpjWXFGS0ttRWU2a2hSTXpCJTJCc3FLZmZKYTBoY0dMT1ZXQmh1ZVVwbURsYW10MW9wSVR0Rlo2VGxmUyUyRlE3ODdkQ3JpNTFiVjR4JTJGa3lBSEVsMCUyRktDZWlqWmM5MmVhVmFoR2tPZFFrbFk4RHduS0lXRDFXdTA0YlpaTmpueVVxQTRjJTNE";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        requestPermission();
        findViewById(R.id.tv_test).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                AliPayUtli2.payModle(MainActivity.this, oo, new AliPayUtli2.PayCallBack() {
//                    @Override
//                    public void parResult(PayResult payResult) {
//
//                    }
//                });
//                AliPayUtli.payModle18(MainActivity.this, oo, new AliPayUtli.PayCallBack() {
//                    @Override
//                    public void parResult(PayResult payResult) {
//
//                    }
//                });
//                AliPayUtli.payModle16(MainActivity.this, oo, new AliPayUtli.PayCallBack() {
//                    @Override
//                    public void parResult(com.mo.kpay.ali.aliModle.modle16.PayResult payResult) {
//
//                    }
//                });

            }
        });
    }

    private void requestPermission() {
        // Here, thisActivity is the current activity
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE)
                != PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this,
                    new String[]{
                            Manifest.permission.READ_PHONE_STATE,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE
                    }, 1);

        } else {
//            showToast(this, getString(R.string.permission_already_granted));
        }
    }
}
