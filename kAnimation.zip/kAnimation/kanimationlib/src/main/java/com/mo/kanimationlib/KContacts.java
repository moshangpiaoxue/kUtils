package com.mo.kanimationlib;

/**
 * @ author：mo
 * @ data：2019/6/26:14:01
 * @ 功能：常量类
 */
public class KContacts {
    /**
     * 动画默认持续时间
     */
    public static int defultDuration = 500;


}
