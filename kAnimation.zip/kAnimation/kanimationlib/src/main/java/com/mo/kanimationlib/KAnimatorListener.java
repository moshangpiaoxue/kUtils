package com.mo.kanimationlib;

import android.view.animation.Animation;

/**
 * @ author：mo
 * @ data：2018/1/13：17:02
 * @ 功能：动画监听
 */
public class KAnimatorListener implements Animation.AnimationListener {
    /**
     * 动画开始
     *
     * @param animation
     */
    @Override
    public void onAnimationStart(Animation animation) {

    }

    /**
     * 动画结束
     *
     * @param animation
     */
    @Override
    public void onAnimationEnd(Animation animation) {

    }

    /**
     * 动画重复
     *
     * @param animation
     */
    @Override
    public void onAnimationRepeat(Animation animation) {

    }
}
