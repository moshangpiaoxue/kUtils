package com.mo.kanimationlib.layout;

/**
 * @ author：mo
 * @ data：2019/6/27:18:01
 * @ 功能：
 */
public class KLayoutAnimationUtil {

//    public static LayoutAnimationController getLayoutAnimationController(Context context){
//        LayoutAnimationController layoutAnimationController =
//                new LayoutAnimationController(AnimationUtils.loadAnimation(context, R.anim.scale));
//        //item 出现顺序
//        layoutAnimationController.setOrder(LayoutAnimationController.ORDER_NORMAL);
//    }
}
