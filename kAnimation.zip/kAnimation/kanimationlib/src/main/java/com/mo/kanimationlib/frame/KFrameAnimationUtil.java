package com.mo.kanimationlib.frame;

import android.graphics.drawable.AnimationDrawable;
import android.view.View;

import com.mo.kanimationlib.R;

/**
 * @ author：mo
 * @ data：2019/6/27:17:59
 * @ 功能：帧动画
 */
public class KFrameAnimationUtil {
    public static void getFrameAnimation(View view) {
        view.setBackgroundResource(R.drawable.dialog_rotate);
        AnimationDrawable drawable = (AnimationDrawable) view.getBackground();
        drawable.start();

    }
}
