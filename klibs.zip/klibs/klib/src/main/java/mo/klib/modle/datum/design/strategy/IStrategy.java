package mo.klib.modle.datum.design.strategy;

/**
 * @author：mo
 * @data：2018/6/1 0001
 * @功能： 接口，设置要做什么
 */

public interface IStrategy {
    int getCount(int money);
}
