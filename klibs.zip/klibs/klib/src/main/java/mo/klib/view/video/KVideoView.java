package mo.klib.view.video;

import android.content.Context;
import android.media.MediaPlayer;
import android.widget.VideoView;

/**
 * @ author：mo
 * @ data：2019/1/9
 * @ 功能：
 */
public class KVideoView extends VideoView {

    public KVideoView(Context context) {
        super(context);
    }

//     video.setVideoURI(data.getData());//为视频播放器设置视频路径
//            video.setMediaController(new MediaController(mActivity));//显示控制栏
//            video.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
//        @Override
//        public void onPrepared(MediaPlayer mp) {
//            video.start();//开始播放视频
//        }
//    });
}
