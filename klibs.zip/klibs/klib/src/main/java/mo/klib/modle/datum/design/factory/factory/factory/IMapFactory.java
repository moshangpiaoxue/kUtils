package mo.klib.modle.datum.design.factory.factory.factory;


import mo.klib.modle.datum.design.factory.factory.map.IMapView;

public interface IMapFactory {
	public IMapView getMapView();
}
