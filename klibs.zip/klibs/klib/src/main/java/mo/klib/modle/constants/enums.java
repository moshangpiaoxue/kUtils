package mo.klib.modle.constants;


import android.content.pm.ActivityInfo;

/**
 * @ author：mo
 * @ data：2019/1/31:18:07
 * @ 功能：
 */
public class enums {
}
