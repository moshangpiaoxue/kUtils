package mo.klib.modle.listener.receiverListener;

/**
 * @ author：mo
 * @ data：2018/12/14
 * @ 功能：GPS开关监听
 */
public interface KOnGpsChangeListener {
    void onGpsStatusChange(Boolean isOpen);
}
