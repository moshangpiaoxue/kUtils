package mo.klib.utils.dataUtil;

/**
 * @ author：mo
 * @ data：2017/11/20 0020
 * @ 功能：
 */

public class IntegerUtil {
    public static int getInteger(String str) {
        return Integer.parseInt(str);
    }
}
