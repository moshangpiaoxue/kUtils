package mo.kxutils;

import android.content.Intent;
import android.graphics.Bitmap;
import android.view.View;
import android.widget.ImageView;

import mo.klib.modle.viewHolder.ViewHolder;
import mo.klib.ui.activity.KBaseActivity;

public class MainActivity extends KBaseActivity {
    private ImageView iv_main;

    @Override
    protected int getLayoutId() {
        return R.layout.activity_main;
    }

    @Override
    protected void initView(ViewHolder mViewHolder, View rootView) {
        iv_main = findViewById(R.id.iv_main);
        iv_main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HttpLoadingUtil.INSTANCE.show(mActivity);
//                ProgressDialogUtil.showProgress(mActivity,"ssssssss");
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        HttpLoadingUtil.INSTANCE.dimiss();
    }

    @Override
    protected void setMediaResult(int phontoType, Bitmap bitmap, String path, Intent data) {
        super.setMediaResult(phontoType, bitmap, path, data);
        iv_main.setImageBitmap(bitmap);
    }

}
