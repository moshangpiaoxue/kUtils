package mo.kxutils;

/**
 * @ author：mo
 * @ data：2019/3/27:13:53
 * @ 功能：
 */
public class TestActivity2 extends TestActivity {
    @Override
    protected int getLayoutId() {
        return 0;
    }
}
