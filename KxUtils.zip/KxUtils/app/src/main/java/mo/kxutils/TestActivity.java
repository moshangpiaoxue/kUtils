package mo.kxutils;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;

/**
 * @ author：mo
 * @ data：2019/3/27:13:51
 * @ 功能：
 */
public abstract class TestActivity extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(getLayoutId());
    }

    protected abstract int getLayoutId();
}
