package mo.kxutils;

import mo.klib.k;
import mo.lib.KxUtilsApplication;

/**
 * @ author：mo
 * @ data：2019/3/27:13:27
 * @ 功能：
 */
public class KApplication extends KxUtilsApplication {
    @Override
    public void onCreate() {
        super.onCreate();
        k.Ext.init(this);
    }
}
