package mo.kxutils;

import android.app.Activity;

/**
 * @ author：mo
 * @ data：2019/5/8:14:47
 * @ 功能：
 */
public enum HttpLoadingUtil {
    /**
     * 单例
     */
    INSTANCE;
    private HttpLoading httpLoading;

    HttpLoadingUtil() {
    }

    public void show(Activity mActivity) {
        if (httpLoading == null) {
            httpLoading = new HttpLoading(mActivity);
        }
        httpLoading.show();
    }

    public void dimiss() {
        httpLoading.dismiss();
    }
}
