package mo.kxutils;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.view.View;

/**
 * @ author：mo
 * @ data：2019/5/8:11:35
 * @ 功能：
 */
public class HttpLoading extends BaseDialog {
    public HttpLoading(Activity mActivity) {
        super(mActivity);
    }

    @Override
    protected int getLayoutId() {
        return R.layout.dialog_loading;
    }

    @Override
    protected void doWhat(Dialog dialog, View view) {
    }
}
