package com.mo.kumenglibs.login;

import android.app.Activity;
import android.content.Intent;

import com.umeng.socialize.UMShareAPI;
import com.umeng.socialize.bean.SHARE_MEDIA;

import java.util.Map;

/**
 * @ author：mo
 * @ data：2019/4/17:9:10
 * @ 功能：
 */
public class LoginUtil {
    private Activity mActivity;

    public LoginUtil(Activity mActivity) {
        this.mActivity = mActivity;
    }

    public void actionLogin(final SHARE_MEDIA platform,KUMAuthListener listener) {
        UMShareAPI.get(mActivity).getPlatformInfo(mActivity,platform,listener);
    }

    /**
     * 在activity的 onActivityResult里调用，必用
     */
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        UMShareAPI.get(mActivity).onActivityResult(requestCode, resultCode, data);
    }

}
