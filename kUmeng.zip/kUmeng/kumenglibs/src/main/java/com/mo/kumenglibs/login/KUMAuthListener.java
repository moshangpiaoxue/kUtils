package com.mo.kumenglibs.login;

import com.umeng.socialize.UMAuthListener;
import com.umeng.socialize.bean.SHARE_MEDIA;

import java.util.Map;

/**
 * @ author：mo
 * @ data：2018/10/11
 * @ 功能：友盟授权监听回调
 */
public class KUMAuthListener implements UMAuthListener {
    /**
     * 授权开始
     */
    @Override
    public void onStart(SHARE_MEDIA share_media) {

    }

    /**
     * //授权成功，即登陆成功后这里返回Map<String, String> map，map里面就是用户的信息，可以拿出来使用了
     *
     * @param share_media
     * @param i
     * @param map
     */
    @Override
    public void onComplete(SHARE_MEDIA share_media, int i, Map<String, String> map) {

    }

    /**
     * 授权失败
     */
    @Override
    public void onError(SHARE_MEDIA share_media, int i, Throwable throwable) {
        throwable.printStackTrace();
    }

    /**
     * 取消授权
     */
    @Override
    public void onCancel(SHARE_MEDIA share_media, int i) {

    }
}
