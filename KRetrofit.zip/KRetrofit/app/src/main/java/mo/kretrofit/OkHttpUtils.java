package mo.kretrofit;

import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.util.Log;
import java.io.IOException;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * 作者：mafuyan
 * 时间：2019/3/25
 * 作用：OkHttp网络请求工具类
 */
public class OkHttpUtils {

    private HttpListener listener;
    private final int HTTP_SUCCESS =100 ; //定义成功常量
    private final int HTTP_ERROR = 101;//定义失败常量

    //封装handler  重写handleMessage方法
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case HTTP_SUCCESS://成功
                    String data = (String) msg.obj;
                    listener.success(data);
                    break;
                case HTTP_ERROR://失败
                    String error = (String) msg.obj;
                    listener.fail(error);
                    break;
            }
        }
    };


    //添加网络拦截器
    @NonNull
    private OkHttpClient getOkHttpClient() throws IOException {
        return new OkHttpClient.Builder().
                addNetworkInterceptor(new Interceptor() {
                    @Override
                    public Response intercept(Chain chain) throws IOException {
                        Request request = chain.request();//拦截
                        String mehod = request.method();//请求类型
                        String host = request.url().host();//接口域名
                        Log.i("intercept", mehod + "==" + host);
//                        Response proceed = chain.proceed(request);
                        return chain.proceed(request);//返回Response
                    }
                }).build();

        //添加应用拦截器
        //                addInterceptor(new Interceptor() {
        //                    @Override
        //                    public Response intercept(Chain chain) throws IOException {
        //                        Request request = chain.request();
        //                        String mehod = request.method();
        //                        String host = request.url().host();
        //                        Log.i("intercept", mehod + "==" + host);
//                                  Response proceed = chain.proceed(request);
        //                        return chain.proceed(request); //返回Response
        //                    }
        //                }).
        //                build();
    }

    private void doCall(Call call) throws IOException {
        final Message message = Message.obtain();
        call.enqueue(new Callback() {
            //失败方法
            @Override
            public void onFailure(Call call, IOException e) {
                message.what = HTTP_ERROR;
                message.obj = e.getMessage();
                handler.sendMessage(message);
            }
            //成功方法
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                message.what = HTTP_SUCCESS;//标识
                message.obj = response.body().string();//对象
                handler.sendMessage(message);//发送消息
            }
        });
    }

    //get请求
    public OkHttpUtils get(String url) {
        try {
            OkHttpClient client = getOkHttpClient();
            Request request = new Request.Builder()
                    .url(url)
                    .build();
            Call call = client.newCall(request);
            doCall(call);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return this;
    }

    //post请求
    public OkHttpUtils post(String url, RequestBody body) {
        try {
            OkHttpClient client = getOkHttpClient();
            Request request = new Request.Builder()
                    .post(body)
                    .url(url)
                    .build();
            Call call = client.newCall(request);
            doCall(call);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return this;
    }


    //接口回调方法
    public void result(HttpListener listener) {
        this.listener = listener;
    }

    //定义接口
    public interface HttpListener {
        void success(String data);//成功
        void fail(String error);//失败
    }
}