//package mo.kretrofit;
//
//import com.google.gson.Gson;
//
//import java.lang.reflect.ParameterizedType;
//
//import io.reactivex.disposables.Disposable;
//import mo.lib.java.KBaseObserver;
//
///**
// * @ author：mo
// * @ data：2019/2/26:18:25
// * @ 功能：
// */
//public abstract class KBaseObserver2<T> extends KBaseObserver {
//
//    /**
//     * 在回调类拿到泛型类，Gson解析用
//     */
//    private Class<T> getTClass() {
//        Class<T> tClass = (Class<T>) ((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[0];
//        return tClass;
//    }
//
//    @Override
//    protected void kOnSubscribe(Disposable d) {
//
//    }
//
//    @Override
//    protected void kOnNext(String body) {
//        onSuccess("".getClass().equals(getTClass()) ? (T) body : (T) (new Gson()).fromJson(body, getTClass()));
//    }
//
//    protected abstract void onSuccess(T t);
//
//    @Override
//    protected void kOnError(Throwable e) {
//
//    }
//
//    @Override
//    protected void kOnComplete() {
//
//    }
//}
