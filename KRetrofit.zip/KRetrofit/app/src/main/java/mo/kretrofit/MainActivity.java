package mo.kretrofit;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import java.util.HashMap;
import java.util.Map;

import mo.lib.java.KBaseObserver;
import mo.lib.k2;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        k2.Ext.setBaseUrl("http://192.168.5.228:20101/");
        Map<String, String> map = new HashMap<>();
        map.put("username", "fanfan");
        map.put("password", "1");
        k2.http().post("inspec/sys/login", map, new KBaseObserver<String>() {


            @Override
            protected void kOnNext(String body) {

            }
        });
OkHttpUtils okHttpUtils=new OkHttpUtils();
okHttpUtils.get("").result(new OkHttpUtils.HttpListener() {
    @Override
    public void success(String data) {

    }

    @Override
    public void fail(String error) {

    }
});

    }
}


