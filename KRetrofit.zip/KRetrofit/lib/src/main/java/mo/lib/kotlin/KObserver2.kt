package mo.lib.kotlin

import io.reactivex.Observer
import io.reactivex.disposables.Disposable

/**
 * @ author：mo
 * @ data：2019/2/20:14:28
 * @ 功能：
 */
class  KObserver2 <T> (var listener: KRetrofitHttp.KRetrofitHttpListener<T>):Observer<T>{
    override fun onComplete() {
    }

    override fun onSubscribe(d: Disposable) {
    }

    override fun onNext(t: T) {
        listener.onSuccess(t)
    }

    override fun onError(e: Throwable) {
        listener.onFail(e)
    }

}