package mo.lib.kotlin;

/**
 * @ author：mo
 * @ data：2019/2/27:18:30
 * @ 功能：
 */
public interface KRetrofitHttpListener<T> {
    void onSuccess(T result);
    void onFail( Throwable error);
}