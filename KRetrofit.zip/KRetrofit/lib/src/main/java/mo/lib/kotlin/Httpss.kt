package mo.lib.kotlin

import android.app.Activity
import mo.lib.k2
import okhttp3.ResponseBody

/**
 * @ author：mo
 * @ data：2019/2/27:18:29
 * @ 功能：
 */

inline fun <reified T> Activity.HttpRetrofit(url: String, map: Map<String, String>?, onRetrofitListener: KBaseObserver2<T>) {
    k2.http().post(url, map, object : KBaseObserver2<T>() {
        override fun onNext(responseBody: ResponseBody) {
            super.onNext(responseBody)
            onRetrofitListener.onNext(responseBody)
        }

        override fun onError(error: Throwable) {
            super.onError(error)
            onRetrofitListener.onError(error)
        }
    })


//            k2.http().post(url, map, KObserver2(object : KRetrofitHttp.KRetrofitHttpListener<ResponseBody> {
//        override fun onFail(error: Throwable?) {
//            onRetrofitListener.onFail(error)
//        }
//
//        override fun onSuccess(body: ResponseBody) {
//            body.string().let {
//                //                onRetrofitListener.onSuccess(Gson().fromJson(it, T::class.java))
//                val jObject = JSONObject(it)
//                val status = jObject.get("status") as Int
//                if (status != 1) {
//                    val msg = jObject.get("data") as String
//                    if (!StringUtil.isEmpty(msg)) {
//                        this@HttpRetrofit2.showToast(msg)
//                    }
//                } else {
//                    onRetrofitListener.onSuccess(Gson().fromJson(it, T::class.java))
//                }
//            }
//        }
//    }));
}