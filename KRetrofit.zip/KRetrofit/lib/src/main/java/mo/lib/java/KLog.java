package mo.lib.java;

import android.util.Log;

import mo.lib.k2;

/**
 * @ author：mo
 * @ data：2019/2/27:16:01
 * @ 功能：
 */
public class KLog {

    public static void i(String string) {
        if (k2.isDebug()) {
            Log.i(k2.TAG(), string);
        }
    }
}
