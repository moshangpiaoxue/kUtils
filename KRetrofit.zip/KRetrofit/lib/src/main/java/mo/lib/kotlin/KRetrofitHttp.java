package mo.lib.kotlin;

/**
 * @ author：mo
 * @ data：2019/1/22
 * @ 功能：Retrofit 网络请求调用方法
 */
public class KRetrofitHttp {
   public interface KRetrofitHttpListener<T> {
        void onSuccess(T result);
        void onFail(Throwable error);
    }
}
